import './BigAbout.css';

function TextBox() {
    return (
        <div id="textblock">
            <div id="textblock-container">
                <h1 id="textblock-title">What is Firewatch?</h1>
                
               
                
            </div>
            <footer id='textblock-footer'>Demo Created With 🧡 By&nbsp;<a id="textblock-devsense" href="https://youtube.com/c/DevSense19">DevSense</a></footer>
        </div>
    );
}

export default TextBox;