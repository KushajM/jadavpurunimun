import React from "react";

export const links = [
  
  {
    name: "Home",
    hash: "/",
  },
  {
    name: "About",
    hash: "/big",
  },
  {
    name:"Committees",
    hash:"/bigcmt",
  },
 
  {
    name: "Blog",
    hash: "/blog",
  },
  
];
